# 📣 Programmes & Outreach agents

| Agent | What it does | Built with | Owner |
|---|---|---|---|
| [📊 Programme Reporting](01_Programme_Reporting.md) | Drafts activity and narrative report sections from the workplan, logframe and meeting notes. | Copilot Studio Lite | Senior Manager (Programmes) |
| [🗣️ Comms & Translation Drafter](02_Comms_and_Translation_Drafter.md) | Turns approved findings into press releases, posts and Sinhala and Tamil drafts in our voice. | Copilot Studio Lite | Communications Officer |
| [🗓️ Dialogue & Event Planner](03_Dialogue_and_Event_Planner.md) | Plans community dialogues and workshops: agenda, logistics, safeguarding and follow-up. | Copilot Studio Lite | Senior Manager (Programmes) |
