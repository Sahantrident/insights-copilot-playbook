# 🛠️ How to build Insights agents

This folder has one build guide per agent, grouped by focus area. Every guide follows the same steps, so once you've built one, the rest are quick.

> ⚠️ Menu names in Microsoft 365 change often. If a button below has a slightly different name in your tenant, look for the closest match. Check licensing and billing notes with Trident before sharing an agent widely.

## 1. Which tool?

| | **Copilot Studio Lite** (the agent builder inside Microsoft 365 Copilot) | **Copilot Studio (full)** |
|---|---|---|
| Who builds | Any licensed Copilot user, in minutes | Trident or a trained champion |
| Best for | Internal helpers over our own SharePoint files and policies | Public or external agents, multi-step flows, connectors, authentication |
| Where it runs | Microsoft 365 Copilot app, Teams | Website, Teams, other channels |
| Insights agents | 16 of the 17 in this pack | Ask the Barometer (public) |
| Cost | Included for licensed users; unlicensed users may be billed pay-as-you-go ⚠️ check | Billed by message capacity ⚠️ check current model and nonprofit offers |

## 2. Before you build (every agent)
- [ ] The knowledge folder exists in SharePoint and holds **only** the documents the agent should use.
- [ ] Permissions on that folder are correct. **The agent can only see what the user can see**, but anything in the folder may appear in answers.
- [ ] No identifiable respondent data, salaries or confidential donor terms in the folder.
- [ ] Sensitivity labels applied (Public / Internal / Confidential). Highly Confidential – Respondent Data is never connected.
- [ ] An owner is named and a review date set.

## 3. Build it in Copilot Studio Lite (about 15 minutes)
1. Open **Microsoft 365 Copilot** (m365.cloud.microsoft) and sign in with your work account.
2. In the left pane choose **Agents**, then **Create agent** (sometimes "New agent").
3. Switch to the **Configure** tab (the **Describe** tab lets you build by chatting, but Configure gives you full control).
4. Fill in:
   - **Name** and **icon**: use the emoji and name from the guide.
   - **Description**: one line from the guide ("What it does").
   - **Instructions**: paste the full block from the guide.
   - **Knowledge**: add the SharePoint sites, folders or files listed. Turn web search on or off as the guide says.
   - **Capabilities**: turn Code interpreter / Image generator on or off as listed.
   - **Suggested prompts** (starter prompts): add the 4 from the guide.
5. Select **Create**. Test it in the right-hand pane with the test questions in the guide.
6. **Share** it with the people listed under "Users" (specific people or a group), not with the whole organisation unless the guide says so.

## 4. Test before sharing
Run every test question in the guide. If an answer breaks a rule, tighten the instructions or remove the document that caused it, and test again.

## 5. Naming and housekeeping
- Name agents "Insights – <Agent name>" so staff can find them.
- Keep a list of agents, owners and review dates on the Copilot hub page in SharePoint.
- Review each agent on the cadence in its guide. Retire agents no one uses after 90 days.

## 6. Agents in this pack
| Focus area | Agent | What it does | Built with |
|---|---|---|---|
| 👩🏽‍💼 Leadership & Board | [🗂️ Board Secretary](1_Leadership/01_Board_Secretary.md) | Drafts board papers and minutes, and tracks every board decision and action. | Copilot Studio Lite |
| 👩🏽‍💼 Leadership & Board | [🤝 Donor Meeting Prep](1_Leadership/02_Donor_Meeting_Prep.md) | Builds a one-page brief before any donor or partner meeting. | Copilot Studio Lite |
| 👩🏽‍💼 Leadership & Board | [✍️ Proposal Builder](1_Leadership/03_Proposal_Builder.md) | Drafts concept notes and proposal sections from approved boilerplate and past results. | Copilot Studio Lite |
| 💰 Finance & Grants | [📜 Grant Compliance](2_Finance_and_Grants/01_Grant_Compliance.md) | Answers 'Is this cost eligible?' and 'What's due when?' with clause references. | Copilot Studio Lite |
| 💰 Finance & Grants | [📆 Month-End Close Assistant](2_Finance_and_Grants/02_Month-End_Close_Assistant.md) | Walks through the close checklist and runs ledger checks on an uploaded export. | Copilot Studio Lite |
| 💰 Finance & Grants | [💬 Finance Policy Helpdesk](2_Finance_and_Grants/03_Finance_Policy_Helpdesk.md) | Answers staff questions on expense claims, per diems, advances and procurement. | Copilot Studio Lite |
| 💰 Finance & Grants | [🧾 Audit Ready](2_Finance_and_Grants/04_Audit_Ready.md) | Builds audit and expenditure-verification checklists and tracks what is ready. | Copilot Studio Lite |
| 🔬 Research (SLB) | [📚 SLB Knowledge](3_Research/01_SLB_Knowledge.md) | Answers questions about the Sri Lanka Barometer from published reports and concept notes. | Copilot Studio Lite |
| 🔬 Research (SLB) | [🔎 Literature Scout](3_Research/02_Literature_Scout.md) | Finds and summarises recent research and grey literature, with citations and evidence grading. | Copilot Studio Lite |
| 🔬 Research (SLB) | [🏷️ Qualitative Coding Assistant](3_Research/03_Qualitative_Coding_Assistant.md) | Applies the agreed codebook to anonymised transcripts and suggests new codes. | Copilot Studio Lite |
| 🔬 Research (SLB) | [🧪 Methods & Ethics Reviewer](3_Research/04_Methods_and_Ethics_Reviewer.md) | Reviews research designs, questionnaires and outputs against our methods and ethics standards. | Copilot Studio Lite |
| 📣 Programmes & Outreach | [📊 Programme Reporting](4_Programmes_and_Outreach/01_Programme_Reporting.md) | Drafts activity and narrative report sections from the workplan, logframe and meeting notes. | Copilot Studio Lite |
| 📣 Programmes & Outreach | [🗣️ Comms & Translation Drafter](4_Programmes_and_Outreach/02_Comms_and_Translation_Drafter.md) | Turns approved findings into press releases, posts and Sinhala and Tamil drafts in our voice. | Copilot Studio Lite |
| 📣 Programmes & Outreach | [🗓️ Dialogue & Event Planner](4_Programmes_and_Outreach/03_Dialogue_and_Event_Planner.md) | Plans community dialogues and workshops: agenda, logistics, safeguarding and follow-up. | Copilot Studio Lite |
| 🏢 Organisation-wide | [🎓 Copilot Coach](5_Organisation_Wide/01_Copilot_Coach.md) | Helps staff write better prompts, suggests 4C habits and checks prompts against the AI use policy. | Copilot Studio Lite |
| 🏢 Organisation-wide | [🧭 Insights Helpdesk](5_Organisation_Wide/02_Insights_Helpdesk.md) | Answers HR, admin and IT how-to questions from the staff handbook and policies. | Copilot Studio Lite |
| 🏢 Organisation-wide | [🌐 Ask the Barometer (public)](5_Organisation_Wide/03_Ask_the_Barometer_public.md) | A public website agent that answers questions from published SLB data only, with citations. | Copilot Studio (full) |
