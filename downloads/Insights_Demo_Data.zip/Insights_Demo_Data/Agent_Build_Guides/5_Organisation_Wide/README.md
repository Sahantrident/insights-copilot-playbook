# 🏢 Organisation-wide agents

| Agent | What it does | Built with | Owner |
|---|---|---|---|
| [🎓 Copilot Coach](01_Copilot_Coach.md) | Helps staff write better prompts, suggests 4C habits and checks prompts against the AI use policy. | Copilot Studio Lite | Champions (Finance + Programmes) |
| [🧭 Insights Helpdesk](02_Insights_Helpdesk.md) | Answers HR, admin and IT how-to questions from the staff handbook and policies. | Copilot Studio Lite | Finance & Administration Manager |
| [🌐 Ask the Barometer (public)](03_Ask_the_Barometer_public.md) | A public website agent that answers questions from published SLB data only, with citations. | Copilot Studio (full) | Executive Director + Trident |
