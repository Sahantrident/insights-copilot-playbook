# 👩🏽‍💼 Leadership & Board agents

| Agent | What it does | Built with | Owner |
|---|---|---|---|
| [🗂️ Board Secretary](01_Board_Secretary.md) | Drafts board papers and minutes, and tracks every board decision and action. | Copilot Studio Lite | Executive Director |
| [🤝 Donor Meeting Prep](02_Donor_Meeting_Prep.md) | Builds a one-page brief before any donor or partner meeting. | Copilot Studio Lite | Executive Director |
| [✍️ Proposal Builder](03_Proposal_Builder.md) | Drafts concept notes and proposal sections from approved boilerplate and past results. | Copilot Studio Lite | Executive Director |
