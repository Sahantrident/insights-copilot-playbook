# 💰 Finance & Grants agents

| Agent | What it does | Built with | Owner |
|---|---|---|---|
| [📜 Grant Compliance](01_Grant_Compliance.md) | Answers 'Is this cost eligible?' and 'What's due when?' with clause references. | Copilot Studio Lite | Finance & Administration Manager |
| [📆 Month-End Close Assistant](02_Month-End_Close_Assistant.md) | Walks through the close checklist and runs ledger checks on an uploaded export. | Copilot Studio Lite | Finance & Administration Manager |
| [💬 Finance Policy Helpdesk](03_Finance_Policy_Helpdesk.md) | Answers staff questions on expense claims, per diems, advances and procurement. | Copilot Studio Lite | Finance & Administration Manager |
| [🧾 Audit Ready](04_Audit_Ready.md) | Builds audit and expenditure-verification checklists and tracks what is ready. | Copilot Studio Lite | Finance & Administration Manager |
