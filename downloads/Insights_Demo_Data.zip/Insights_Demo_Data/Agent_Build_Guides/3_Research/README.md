# 🔬 Research (SLB) agents

| Agent | What it does | Built with | Owner |
|---|---|---|---|
| [📚 SLB Knowledge](01_SLB_Knowledge.md) | Answers questions about the Sri Lanka Barometer from published reports and concept notes. | Copilot Studio Lite | Senior Manager (Programmes) + Research Expert |
| [🔎 Literature Scout](02_Literature_Scout.md) | Finds and summarises recent research and grey literature, with citations and evidence grading. | Copilot Studio Lite | Research Expert |
| [🏷️ Qualitative Coding Assistant](03_Qualitative_Coding_Assistant.md) | Applies the agreed codebook to anonymised transcripts and suggests new codes. | Copilot Studio Lite | Research Expert |
| [🧪 Methods & Ethics Reviewer](04_Methods_and_Ethics_Reviewer.md) | Reviews research designs, questionnaires and outputs against our methods and ethics standards. | Copilot Studio Lite | Research Expert |
